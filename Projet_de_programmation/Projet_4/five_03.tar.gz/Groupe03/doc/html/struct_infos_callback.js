var struct_infos_callback =
[
    [ "colonne_actuelle", "struct_infos_callback.html#a9946898d4c78e68692c781b6a6503e06", null ],
    [ "ligne_actuelle", "struct_infos_callback.html#a9ac88912e1574bb856460570bd975fcc", null ],
    [ "plateau", "struct_infos_callback.html#a4a9c818b9879878aa5681bd71d727901", null ]
];