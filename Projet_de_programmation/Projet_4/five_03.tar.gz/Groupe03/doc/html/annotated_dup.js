var annotated_dup =
[
    [ "Boule", "struct_boule.html", "struct_boule" ],
    [ "Case_t", "struct_case__t.html", null ],
    [ "Data", "struct_data.html", "struct_data" ],
    [ "InfosCallback", "struct_infos_callback.html", "struct_infos_callback" ],
    [ "MiseAJour", "struct_mise_a_jour.html", "struct_mise_a_jour" ],
    [ "Plateau_t", "struct_plateau__t.html", null ],
    [ "Score_t", "struct_score__t.html", null ]
];