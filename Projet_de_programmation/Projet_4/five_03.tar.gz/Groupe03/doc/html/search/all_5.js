var searchData=
[
  ['fenetre_5fprincipale_0',['fenetre_principale',['../controle_8h.html#a9961cf4b99c133009d4e322814597b6b',1,'controle.h']]],
  ['fichier_5fscores_1',['fichier_scores',['../controle_8h.html#ab915e39405b4f7b21ce8caaf2898a8ea',1,'controle.h']]]
];
