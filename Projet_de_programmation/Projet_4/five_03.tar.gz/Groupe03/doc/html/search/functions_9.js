var searchData=
[
  ['recreer_5fgrille_0',['recreer_grille',['../controle_8h.html#af5dd5875f78daeda7d467f7c83681963',1,'controle.h']]],
  ['redemarrer_5fjeu_1',['redemarrer_jeu',['../vue_8h.html#a373dcf5cef682c205581eb007629e939',1,'vue.h']]]
];
