var searchData=
[
  ['nouvelle_5fpartie_0',['nouvelle_partie',['../controle_8h.html#a90f708d7bef6566945c4a49b0e0caeeb',1,'controle.h']]]
];
