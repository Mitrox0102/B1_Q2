var searchData=
[
  ['data_0',['Data',['../struct_data.html',1,'']]]
];
