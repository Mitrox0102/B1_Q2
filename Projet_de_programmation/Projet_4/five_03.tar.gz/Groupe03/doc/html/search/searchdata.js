var indexSectionsWithContent =
{
  0: "abcdefgijlmnopqrstuv",
  1: "bcdimps",
  2: "cmuv",
  3: "acdgimnpqrstv",
  4: "cefgilp",
  5: "cps",
  6: "c",
  7: "bcjmorv",
  8: "im"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

