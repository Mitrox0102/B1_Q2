var searchData=
[
  ['score_0',['Score',['../modele_8h.html#a8222fedbb24d3db94eba0f1218f9347b',1,'modele.h']]]
];
