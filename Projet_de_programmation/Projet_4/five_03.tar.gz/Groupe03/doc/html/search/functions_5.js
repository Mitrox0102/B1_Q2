var searchData=
[
  ['maj_5fboutons_5fsuivants_0',['maj_boutons_suivants',['../utilis_8h.html#a74b9cc8e97419412a3ae77ec7a9d3203',1,'utilis.h']]],
  ['maj_5fgrille_1',['maj_grille',['../controle_8h.html#a6f3141ce5e86084b71aa2bc0cd76ce66',1,'controle.h']]],
  ['mettre_5fa_5fjour_5fscore_2',['mettre_a_jour_score',['../utilis_8h.html#acc2447c1a9127b31de131f2ed3c4c83c',1,'utilis.h']]]
];
