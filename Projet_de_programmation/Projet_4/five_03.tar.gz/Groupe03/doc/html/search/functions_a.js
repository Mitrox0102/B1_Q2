var searchData=
[
  ['sauvegarder_5fscore_0',['sauvegarder_score',['../modele_8h.html#ad7379a761399cef1ec11e922719b15a2',1,'modele.h']]],
  ['score_5fcreate_1',['score_create',['../modele_8h.html#a3250734ef5e7e6a9c117fd2b1dfe5691',1,'modele.h']]],
  ['score_5fdestroy_2',['score_destroy',['../modele_8h.html#a605d4b7000ec593bd8d29e0e4b1abced',1,'modele.h']]],
  ['score_5fget_5fnom_3',['score_get_nom',['../modele_8h.html#a9b210cec7a8644ba7ec1f02d2426ccf9',1,'modele.h']]],
  ['score_5fget_5fvaleur_4',['score_get_valeur',['../modele_8h.html#a4b27b19e5ab35bc30d26fe476ce49cdf',1,'modele.h']]]
];
