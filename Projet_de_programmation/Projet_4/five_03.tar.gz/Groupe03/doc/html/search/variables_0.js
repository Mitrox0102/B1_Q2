var searchData=
[
  ['colonne_5factuelle_0',['colonne_actuelle',['../struct_infos_callback.html#a9946898d4c78e68692c781b6a6503e06',1,'InfosCallback::colonne_actuelle'],['../struct_mise_a_jour.html#a282136525281fa3ccffdb35ab4a35da2',1,'MiseAJour::colonne_actuelle']]],
  ['couleur_1',['couleur',['../struct_boule.html#ac4ad7f6e9bcfb9548eb64d2ed0f5cfe5',1,'Boule']]]
];
