var searchData=
[
  ['infoscallback_0',['InfosCallback',['../struct_infos_callback.html',1,'']]]
];
