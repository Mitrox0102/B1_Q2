var searchData=
[
  ['trouver_5falignements_0',['trouver_alignements',['../controle_8h.html#a861d3b4685e4e23e02c554e875b0a97b',1,'controle.h']]]
];
