var searchData=
[
  ['score_5ft_0',['Score_t',['../struct_score__t.html',1,'']]]
];
