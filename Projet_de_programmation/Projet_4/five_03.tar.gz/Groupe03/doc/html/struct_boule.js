var struct_boule =
[
    [ "couleur", "struct_boule.html#ac4ad7f6e9bcfb9548eb64d2ed0f5cfe5", null ],
    [ "image", "struct_boule.html#acfbf459082f6e0cf720ba7460451eb6c", null ]
];